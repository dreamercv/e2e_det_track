# Sparse4D + BEV 接入与 TrackHead 方案

**纯 PyTorch 实现（不依赖 mmcv/mmdet）**：见 `projects/sparse4d_bev_torch/`，可直接用于调试与开发，用法见其 `README.md`。

## 1. 整体流程（你的目标）

```
图像 (bs, S, N, 3, 128, 384)
  → 2D 特征 / 你的 BEV backbone
  → BEV 特征 (B*S, 256, 200, 80)，时序已对齐
  → Sparse4D Head（从 BEV 上选特征作为 instance-feature）
  → 多轮 operation_order
  → 输出：instance_feature (B*S, 900, 256)、anchor (B*S, 900, 11)、confidence 等
  → 端到端检测 ✓

TrackHead（独立于 head）
  输入：instance_feature、anchor、ego_pose
  → Cross-Attn 等
  → 判断是否存在跟踪（跨帧关联 / track_id）
```

- **检测**：可以做到端到端（图像 → BEV → Sparse4D head → 检测结果）。
- **跟踪**：当前 head 只做“每帧 900 个 instance”，不做跨帧 ID；用 **TrackHead 后接** instance_feature + anchor + ego_pose 做跨帧关联是合理且常见的做法。

---

## 2. Head 接入 BEV：需要改什么

### 2.1 输入形态

- **原 Sparse4D**：`feature_maps` = 多尺度环视图像特征 `[(B, num_cams, C, H, W), ...]`，`deformable` 用 3D key_points 投影到多相机 2D 再采样。
- **你的方案**：`feature_maps` = **单张 BEV 特征** `[(B*S, 256, H_bev, W_bev)]`（例如 200×80），在 BEV 上按 anchor 的 (x,y) 采样。

因此只需把 head 的“特征来源”从**多视角图像**换成**BEV 图**，并换掉 `deformable` 里的聚合模块。

### 2.2 使用 BEVFeatureAggregation

已在 `mmdet3d_plugin/models/blocks.py` 中实现 **BEVFeatureAggregation**：

- **接口**与 `DeformableFeatureAggregation` 一致：  
  `forward(instance_feature, anchor, anchor_embed, feature_maps, metas)`。
- **语义**：  
  - `feature_maps[0]` = BEV 特征 `(B*S, 256, H_bev, W_bev)`；  
  - 用 `kps_generator(anchor, instance_feature)` 得到 3D key_points，取 **(x, y)** 按 `bev_bounds` 映射到 BEV 网格，再 `grid_sample` 得到每个 instance 的 BEV 特征并融合，残差加回 `instance_feature`。

配置里把原来的 `deformable_model` 换成 BEV 版本即可，例如：

```python
# 原 deformable（环视）
deformable_model=dict(
    type="DeformableFeatureAggregation",
    ...
),

# 改为 BEV
deformable_model=dict(
    type="BEVFeatureAggregation",
    embed_dims=256,
    bev_bounds=([-80.0, 120.0, 1.0], [-40.0, 40.0, 1.0]),  # 与 BEV backbone 的 grid_conf 一致
    kps_generator=dict(type="SparseBox3DKeyPointsGenerator", ...),
    proj_drop=0.1,
    residual_mode="add",
),
```

其他（instance_bank、anchor_encoder、gnn、refine、denoising、loss、decoder）**不用改**，继续用原 Sparse4D 的即可。

### 2.3 时序与 instance_bank

- 若你**一次 forward 喂入整段序列**（B*S 当作 batch），且**不做“多 forward 间”的时序缓存**：
  - 可以保留 `num_temp_instances=0` 或去掉 `temp_gnn`，即**纯单帧/单 batch 检测**，逻辑更简单。
- 若仍想用 instance_bank 做“上一段/上一 forward”的 cache：
  - 需要把 `metas` 里的 `timestamp`、`T_global` 等与你的 **S 帧** 对齐（例如每帧一个 timestamp），这样 `get/update/cache` 的时序语义才一致。

推荐先实现 **B*S 当 batch、不做跨 forward 的 cache**，这样端到端检测最直接；Track 完全交给 TrackHead。

### 2.4 去噪训练

- 沿用现有 **Sparse4D 的 denoising** 即可：  
  sampler 的 `get_dn_anchors`、`dn_metas`、attention mask、dn loss 等都不依赖“特征是来自图像还是 BEV”，只要 head 的输入是 `feature_maps` + `instance_feature/anchor` 即可。
- 只要把 `feature_maps` 换成 BEV、`deformable` 换成 **BEVFeatureAggregation**，去噪训练即可复用了。

---

## 3. TrackHead：用 instance_feature + anchor + ego_pose 做跨帧关联

思路：**检测头只负责每帧的 instance_feature / anchor / confidence；跟踪头在这些结果上做跨帧 cross-attention，输出关联或 track_id**。这是常见且可行的设计。

### 3.1 输入

- **instance_feature**：`(B*S, 900, 256)`，或按帧拆成 list：每帧 `(B, 900, 256)`。
- **anchor**：`(B*S, 900, 11)`（含 x,y,z, 尺寸, yaw, 速度等），同样可按帧拆。
- **ego_pose**：每帧的位姿（如 4×4 或 position + quaternion），用于把历史帧的 anchor 变换到当前帧坐标系，再算相似度/做 attention。

### 3.2 做法简述

- **Query**：当前帧的 instance（或高置信度 subset）的 feature + 位置编码（可用 anchor 的编码）。
- **Key/Value**：上一帧（或前几帧）的 instance，用 **ego_pose** 把 anchor 投影到当前帧，再编码为 key/value。
- **Cross-Attn**：当前帧 query 对历史 key/value 做 attention，得到“当前每个 query 对应哪条历史 track”的权重或匹配分数；再按阈值或匈牙利等得到 **是否同一条 track** 或 **track_id**。

这样：

- **端到端检测**：图像 → BEV → Sparse4D head → instance_feature / anchor / confidence ✓  
- **端到端跟踪**：在 head 输出之上加 TrackHead（cross-attn + 关联），不要求 head 内部有时序 cache，也**可行且清晰**。

### 3.3 注意点

- **ego_pose 对齐**：BEV 和 anchor 都在 ego 系下，历史帧的 anchor 要用 `T_cur2prev` 或 `T_prev2cur` 转到当前帧再参与 attention，否则空间不对齐。
- **训练**：TrackHead 需要跟踪标签（同一物体在不同帧的 instance_id）；检测部分仍用现有 3D 检测 loss，跟踪部分可加 association loss 或 track consistency loss。

---

## 4. 小结

| 问题 | 结论 |
|------|------|
| BEV → Sparse4D head，从 BEV 选特征做 instance-feature，多层 operation_order，去噪训练 | **可行**。把 `feature_maps` 换成 BEV、`deformable` 换成 **BEVFeatureAggregation** 即可，其余 head 逻辑不变。 |
| 端到端检测 | **可以**。图像 → BEV → head → instance_feature / anchor / confidence。 |
| 端到端跟踪 | Head 只做检测；**TrackHead 用 instance_feature + anchor + ego_pose 做 cross-attn 做关联** 的方案 **可行**，且与当前设计兼容。 |

实现顺序建议：  
1）先接好 BEV + BEVFeatureAggregation + 现有 head，跑通检测与去噪；  
2）再在 head 输出上接 TrackHead，用 cross-attn + ego_pose 做跨帧关联与 track_id。
