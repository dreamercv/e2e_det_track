# Sparse4D + BEV 纯 PyTorch 实现

不依赖 **mmcv**、**mmdet**，仅用 **PyTorch** 与 **numpy**，便于本地调试与开发。

## 依赖

- `torch`
- `numpy`

## 结构

- `box3d.py` — 3D box 维度常量
- `instance_bank.py` — InstanceBank（可学习 anchor + 时序 cache）
- `detection3d_blocks.py` — SparseBox3DEncoder / Refinement / KeyPointsGenerator
- `bev_aggregation.py` — BEVFeatureAggregation（从 BEV 图按 anchor 采样）
- `head.py` — Sparse4DHead（operation_order：gnn / norm / deformable / ffn / refine）
- `model.py` — `build_sparse4d_bev_head`、`build_sparse4d_bev_model`

## 快速使用

### 仅 Head（接你自己的 BEV 特征）

```python
from sparse4d_bev_torch import build_sparse4d_bev_head
import torch

head = build_sparse4d_bev_head(
    num_anchor=900,
    embed_dims=256,
    num_decoder=6,
    num_single_frame_decoder=1,
    num_classes=10,
    bev_bounds=([-80.0, 120.0, 1.0], [-40.0, 40.0, 1.0]),
    num_temp_instances=0,  # 0 表示不做跨 forward 的时序 cache
)
# BEV 特征: (B*S, 256, H_bev, W_bev)，例如 (14, 256, 200, 80)
bev = torch.randn(14, 256, 200, 80)
out = head([bev], metas={})
# out["prediction"]: list of (B*S, 900, 11)
# out["classification"]: list of (B*S, 900, num_classes)
# out["quality"]: list of (B*S, 900, 2) or None
```

### 自定义 anchor 初始化

```python
import numpy as np
anchor_init = np.load("nuscenes_kmeans900.npy")  # (900, 11) 或更少
head = build_sparse4d_bev_head(..., anchor_init=anchor_init)
```

### 与自己的 BEV Backbone 串联

先用自己的 backbone 得到 `bev_feature (B*S, 256, H, W)`，再传入 head：

```python
bev_feature = your_bev_backbone(images, ...)  # (B*S, 256, 200, 80)
out = head([bev_feature], metas={})
```

## 与 mmcv 版的对应关系

| mmcv/mmdet 版 | 本实现 |
|---------------|--------|
| `build_from_cfg(instance_bank, PLUGIN_LAYERS)` | 直接 `InstanceBank(...)` |
| `DeformableFeatureAggregation`（环视） | `BEVFeatureAggregation`（BEV 图） |
| `Sparse4DHead` + registry | `Sparse4DHead`，子模块构造好再传入 |
| `@force_fp32` / `BaseModule` | 无，普通 `nn.Module` |
| Sampler / Loss / Decoder | 未实现，可自行接在 head 输出后 |

## 测试

在 `projects` 目录下：

```bash
cd projects
python -m sparse4d_bev_torch.model
```

或任意目录（已把 `projects` 加入 `PYTHONPATH` 时）：

```python
from sparse4d_bev_torch import build_sparse4d_bev_head
head = build_sparse4d_bev_head(num_anchor=100, num_decoder=2)
out = head([torch.randn(14, 256, 200, 80)], {})
print(out["prediction"][0].shape)  # (14, 100, 11)
```
